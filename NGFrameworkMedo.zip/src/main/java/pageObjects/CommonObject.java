package pageObjects;

public class CommonObject {

}
